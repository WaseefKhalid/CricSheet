All Women's One-day Match match data in CSV format
==================================================

The background
--------------

As an experiment, after being asked by a user of the site, I started
converting the YAML data provided on the site into a CSV format. That
initial version was heavily influenced by the format used by the baseball
project Retrosheet. I wasn't sure of the usefulness of my CSV format, but
nothing better was suggested so I persisted with it. Later Ashwin Raman
(https://twitter.com/AshwinRaman_) send me a detailed example of a format
he felt might work and, liking what I saw, I started to produce data in
a slightly modified version of that initial example.

This particular zip folder contains the CSV data for...
  All Women's One-day Match matches
...for which we have data.

A "One-day Match" is a 50-over match between countries that is not regarded
by the ICC as a "One-day International". At it's most basic it's a match that
doesn't involve 2 of the countries "granted" One-day International "status" by
the ICC.

How you can help
----------------

Providing feedback on the data would be the most helpful. Tell me what you
like and what you don't. Is there anything that is in the JSON data that
you'd like to be included in the CSV? Could something be included in a better
format? General views and comments help, as well as incredibly detailed
feedback. All information is of use to me at this stage. I can only improve
the data if people tell me what does works and what doesn't. I'd like to make
the data as useful as possible but I need your help to do it. Also, which of
the 2 CSV formats do you prefer, this one or the original? Ideally I'd like
to settle on a single CSV format so what should be kept from each?

Finally, any feedback as to the licence the data should be released under
would be greatly appreciated. Licensing is a strange little world and I'd
like to choose the "right" licence. My basic criteria may be that:

  * the data should be free,
  * corrections are encouraged/required to be reported to the project,
  * derivative works are allowed,
  * you can't just take data and sell it.

Feedback, pointers, comments, etc on licensing are welcome.

The format of the data
----------------------

Full documentation of this CSV format can be found at:
  https://cricsheet.org/format/csv_ashwin/
but the following is a brief summary of the details...

This format consists of 2 files per match, although you can get all of
the ball-by-ball data from just one of the files. The files for a match
are named <id>.csv (for the ball-by-ball data), and <id>_info.csv (for
the match info), where <id> is the Cricinfo id for the match. The
ball-by-ball file contains one row per delivery in the match, while the
match info file contains match information such as dates the match was
played, the outcome, and lists of the players involved in the match.

The match info file format
--------------------------

The info section contains the information on the actual match, such as
when and where it was played, any event it was part of, the type of
match etc. The fields included in the info section will each appear as
one or more rows in the data. Some of the fields are required, whereas
some are optional. If a field has multiple values, such as team, then
each value will appear on a row of it's own.

The ball-by-ball file format
----------------------------

The first row of each ball-by-ball CSV file contains the headers for the
file, with each subsequent row providing details on a single delivery.
The headers in the file are:

  * match_id
  * season
  * start_date
  * venue
  * innings
  * ball
  * batting_team
  * bowling_team
  * striker
  * non_striker
  * bowler
  * runs_off_bat
  * extras
  * wides
  * noballs
  * byes
  * legbyes
  * penalty
  * wicket_type
  * player_dismissed
  * other_wicket_type
  * other_player_dismissed

Most of the fields above should, hopefully, be self-explanatory, but some may
benefit from clarification...

"innings" contains the number of the innings within the match. If a match is
one that would normally have 2 innings, such as a T20 or ODI, then any innings
of more than 2 can be regarded as a super over.

"ball" is a combination of the over and delivery. For example, "0.3" represents
the 3rd ball of the 1st over.

"wides", "noballs", "byes", "legbyes", and "penalty" contain the total of each
particular type of extras, or are blank if not relevant to the delivery.

If a wicket occurred on a delivery then "wicket_type" will contain the method
of dismissal, while "player_dismissed" will indicate who was dismissed. There
is also the, admittedly remote, possibility that a second dismissal can be
recorded on the delivery (such as when a player retires on the same delivery
as another dismissal occurs). In this case "other_wicket_type" will record
the reason, while "other_player_dismissed" will show who was dismissed.

Matches included in this archive
--------------------------------

2026-05-04 - club - WOD - female - 1513558 - Surrey vs The Blaze
2026-05-02 - club - WOD - female - 1513557 - The Blaze vs Durham
2026-05-02 - club - WOD - female - 1513556 - Essex vs Yorkshire
2026-05-02 - club - WOD - female - 1513555 - Hampshire vs Lancashire
2026-05-02 - club - WOD - female - 1513554 - Warwickshire vs Somerset
2026-04-29 - club - WOD - female - 1513553 - Hampshire vs Surrey
2026-04-29 - club - WOD - female - 1513552 - Warwickshire vs The Blaze
2026-04-29 - club - WOD - female - 1513551 - Somerset vs Essex
2026-04-29 - club - WOD - female - 1513550 - Durham vs Yorkshire
2026-04-25 - club - WOD - female - 1513549 - Durham vs Hampshire
2026-04-25 - club - WOD - female - 1513548 - Somerset vs Surrey
2026-04-25 - club - WOD - female - 1513547 - Yorkshire vs Lancashire
2026-04-25 - club - WOD - female - 1513546 - Essex vs The Blaze
2026-04-19 - club - WOD - female - 1513543 - Lancashire vs Somerset
2026-04-18 - club - WOD - female - 1513545 - Durham vs Surrey
2026-04-18 - club - WOD - female - 1513544 - Yorkshire vs The Blaze
2026-04-18 - club - WOD - female - 1513542 - Essex vs Warwickshire
2026-04-15 - club - WOD - female - 1513541 - Lancashire vs The Blaze
2026-04-15 - club - WOD - female - 1513540 - Yorkshire vs Surrey
2026-04-15 - club - WOD - female - 1513539 - Warwickshire vs Hampshire
2026-04-15 - club - WOD - female - 1513538 - Durham vs Essex
2026-04-11 - club - WOD - female - 1513537 - Essex vs Hampshire
2026-04-11 - club - WOD - female - 1513536 - Yorkshire vs Somerset
2026-04-11 - club - WOD - female - 1513535 - Surrey vs Warwickshire
2026-04-11 - club - WOD - female - 1513534 - Lancashire vs Durham
2025-09-21 - club - WOD - female - 1462401 - Hampshire vs Lancashire
2025-09-17 - club - WOD - female - 1462400 - Surrey vs Hampshire
2025-09-17 - club - WOD - female - 1462399 - Lancashire vs The Blaze
2025-09-13 - club - WOD - female - 1462398 - Warwickshire vs Somerset
2025-09-13 - club - WOD - female - 1462396 - Essex vs The Blaze
2025-09-13 - club - WOD - female - 1462395 - Surrey vs Durham
2025-09-10 - club - WOD - female - 1462393 - Surrey vs Essex
2025-09-10 - club - WOD - female - 1462392 - Warwickshire vs Lancashire
2025-09-09 - club - WOD - female - 1462394 - Durham vs The Blaze
2025-09-07 - club - WOD - female - 1462390 - Essex vs Warwickshire
2025-09-07 - club - WOD - female - 1462389 - Surrey vs Lancashire
2025-09-07 - club - WOD - female - 1462388 - The Blaze vs Somerset
2025-09-07 - club - WOD - female - 1462387 - Durham vs Hampshire
2025-09-04 - club - WOD - female - 1462385 - The Blaze vs Surrey
2025-09-04 - club - WOD - female - 1462384 - Lancashire vs Somerset
2025-09-04 - club - WOD - female - 1462383 - Hampshire vs Essex
2025-07-30 - club - WOD - female - 1462382 - Warwickshire vs Surrey
2025-07-30 - club - WOD - female - 1462381 - Durham vs Somerset
2025-07-30 - club - WOD - female - 1462380 - Lancashire vs Essex
2025-07-30 - club - WOD - female - 1462379 - Hampshire vs The Blaze
2025-07-24 - club - WOD - female - 1462378 - The Blaze vs Warwickshire
2025-07-24 - club - WOD - female - 1462377 - Hampshire vs Surrey
2025-07-24 - club - WOD - female - 1462376 - Somerset vs Essex
2025-07-24 - club - WOD - female - 1462375 - Durham vs Lancashire
2025-05-20 - club - WOD - female - 1462374 - Somerset vs The Blaze
2025-05-19 - club - WOD - female - 1462373 - Lancashire vs Durham
2025-05-19 - club - WOD - female - 1462372 - Warwickshire vs Hampshire
2025-05-19 - club - WOD - female - 1462371 - Surrey vs Essex
2025-05-14 - club - WOD - female - 1462370 - Lancashire vs Warwickshire
2025-05-14 - club - WOD - female - 1462369 - The Blaze vs Surrey
2025-05-14 - club - WOD - female - 1462368 - Essex vs Durham
2025-05-13 - club - WOD - female - 1462367 - Hampshire vs Somerset
2025-05-11 - club - WOD - female - 1462366 - Surrey vs Somerset
2025-05-11 - club - WOD - female - 1462365 - The Blaze vs Lancashire
2025-05-11 - club - WOD - female - 1462364 - Hampshire vs Essex
2025-05-11 - club - WOD - female - 1462363 - Warwickshire vs Durham
2025-05-07 - club - WOD - female - 1462362 - Somerset vs Warwickshire
2025-05-07 - club - WOD - female - 1462361 - Surrey vs Lancashire
2025-05-07 - club - WOD - female - 1462360 - Durham vs Hampshire
2025-05-06 - club - WOD - female - 1462359 - Essex vs The Blaze
2025-05-04 - club - WOD - female - 1462358 - Hampshire vs The Blaze
2025-05-04 - club - WOD - female - 1462357 - Surrey vs Warwickshire
2025-05-04 - club - WOD - female - 1462356 - Lancashire vs Essex
2025-05-04 - club - WOD - female - 1462355 - Durham vs Somerset
2025-05-01 - club - WOD - female - 1462352 - Essex vs Somerset
2025-04-30 - club - WOD - female - 1462354 - The Blaze vs Warwickshire
2025-04-30 - club - WOD - female - 1462353 - Surrey vs Durham
2025-04-30 - club - WOD - female - 1462351 - Lancashire vs Hampshire
2025-04-27 - club - WOD - female - 1462350 - Somerset vs Lancashire
2025-04-27 - club - WOD - female - 1462349 - Hampshire vs Surrey
2025-04-27 - club - WOD - female - 1462348 - Warwickshire vs Essex
2025-04-27 - club - WOD - female - 1462347 - Durham vs The Blaze
2025-04-23 - club - WOD - female - 1462346 - Hampshire vs Warwickshire
2025-04-23 - club - WOD - female - 1462345 - The Blaze vs Lancashire
2025-04-23 - club - WOD - female - 1462344 - Surrey vs Somerset
2025-04-23 - club - WOD - female - 1462343 - Essex vs Durham
2024-09-21 - club - RHF - female - 1427864 - South East Stars vs Sunrisers
2024-09-14 - club - RHF - female - 1427863 - Southern Vipers vs South East Stars
2024-09-14 - club - RHF - female - 1427862 - Northern Diamonds vs Sunrisers
2024-09-07 - club - RHF - female - 1427861 - Sunrisers vs Southern Vipers
2024-09-07 - club - RHF - female - 1427860 - Thunder vs Western Storm
2024-09-07 - club - RHF - female - 1427859 - South East Stars vs Northern Diamonds
2024-09-06 - club - RHF - female - 1427858 - The Blaze vs Central Sparks
2024-09-04 - club - RHF - female - 1427857 - The Blaze vs Thunder
2024-09-04 - club - RHF - female - 1427856 - South East Stars vs Central Sparks
2024-09-04 - club - RHF - female - 1427855 - Western Storm vs Sunrisers
2024-09-04 - club - RHF - female - 1427854 - Southern Vipers vs Northern Diamonds
2024-09-01 - club - RHF - female - 1427853 - Northern Diamonds vs Thunder
2024-08-31 - club - RHF - female - 1427852 - Western Storm vs South East Stars
2024-08-31 - club - RHF - female - 1427851 - Sunrisers vs The Blaze
2024-08-30 - club - RHF - female - 1427850 - Southern Vipers vs Central Sparks
2024-08-26 - club - RHF - female - 1427849 - The Blaze vs Southern Vipers
2024-08-26 - club - RHF - female - 1427848 - Northern Diamonds vs Sunrisers
2024-08-26 - club - RHF - female - 1427847 - Central Sparks vs Western Storm
2024-08-26 - club - RHF - female - 1427846 - Thunder vs South East Stars
2024-07-14 - club - RHF - female - 1427844 - South East Stars vs Sunrisers
2024-07-14 - club - RHF - female - 1427843 - Northern Diamonds vs The Blaze
2024-07-12 - club - RHF - female - 1427842 - Western Storm vs Central Sparks
2024-07-10 - club - RHF - female - 1427841 - South East Stars vs Southern Vipers
2024-07-10 - club - RHF - female - 1427840 - Western Storm vs The Blaze
2024-07-10 - club - RHF - female - 1427839 - Central Sparks vs Thunder
2024-07-10 - club - RHF - female - 1427838 - Sunrisers vs Northern Diamonds
2024-07-07 - club - RHF - female - 1427837 - South East Stars vs Thunder
2024-07-07 - club - RHF - female - 1427836 - Central Sparks vs Sunrisers
2024-07-07 - club - RHF - female - 1427835 - Western Storm vs Northern Diamonds
2024-07-05 - club - RHF - female - 1427834 - The Blaze vs Southern Vipers
2024-06-30 - club - RHF - female - 1427833 - Western Storm vs Southern Vipers
2024-06-30 - club - RHF - female - 1427832 - Sunrisers vs Thunder
2024-06-30 - club - RHF - female - 1427831 - The Blaze vs South East Stars
2024-06-30 - club - RHF - female - 1427830 - Central Sparks vs Northern Diamonds
2024-05-08 - club - RHF - female - 1427829 - Western Storm vs The Blaze
2024-05-08 - club - RHF - female - 1427828 - Thunder vs Central Sparks
2024-05-08 - club - RHF - female - 1427827 - Southern Vipers vs Sunrisers
2024-05-08 - club - RHF - female - 1427826 - Northern Diamonds vs South East Stars
2024-05-06 - club - RHF - female - 1427825 - The Blaze vs Thunder
2024-05-04 - club - RHF - female - 1427824 - Sunrisers vs South East Stars
2024-05-04 - club - RHF - female - 1427823 - Southern Vipers vs Western Storm
2024-05-04 - club - RHF - female - 1427822 - Northern Diamonds vs Central Sparks
2024-05-01 - club - RHF - female - 1427821 - Thunder vs Southern Vipers
2024-05-01 - club - RHF - female - 1427820 - South East Stars vs Western Storm
2024-05-01 - club - RHF - female - 1427819 - Central Sparks vs Sunrisers
2024-05-01 - club - RHF - female - 1427818 - Northern Diamonds vs The Blaze
2024-04-27 - club - RHF - female - 1427817 - Southern Vipers vs Northern Diamonds
2024-04-27 - club - RHF - female - 1427816 - Western Storm vs Thunder
2024-04-27 - club - RHF - female - 1427815 - The Blaze vs Sunrisers
2024-04-27 - club - RHF - female - 1427814 - South East Stars vs Central Sparks
2024-04-24 - club - RHF - female - 1427813 - Central Sparks vs Southern Vipers
2024-04-24 - club - RHF - female - 1427812 - Thunder vs Sunrisers
2024-04-24 - club - RHF - female - 1427811 - Northern Diamonds vs Western Storm
2024-04-24 - club - RHF - female - 1427810 - The Blaze vs South East Stars
2024-04-20 - club - RHF - female - 1427809 - Western Storm vs Sunrisers
2024-04-20 - club - RHF - female - 1427808 - Southern Vipers vs South East Stars
2024-04-20 - club - RHF - female - 1427807 - Central Sparks vs The Blaze
2024-04-20 - club - RHF - female - 1427806 - Thunder vs Northern Diamonds
2023-09-24 - club - RHF - female - 1347460 - The Blaze vs Southern Vipers
2023-09-21 - club - RHF - female - 1347459 - South East Stars vs The Blaze
2023-09-16 - club - RHF - female - 1347458 - Northern Diamonds vs Sunrisers
2023-09-16 - club - RHF - female - 1347457 - Southern Vipers vs The Blaze
2023-09-16 - club - RHF - female - 1347456 - Western Storm vs Thunder
2023-09-16 - club - RHF - female - 1347455 - South East Stars vs Central Sparks
2023-09-13 - club - RHF - female - 1347454 - Western Storm vs Central Sparks
2023-09-13 - club - RHF - female - 1347453 - Sunrisers vs The Blaze
2023-09-13 - club - RHF - female - 1347452 - Northern Diamonds vs Thunder
2023-09-13 - club - RHF - female - 1347451 - Southern Vipers vs South East Stars
2023-09-10 - club - RHF - female - 1347450 - Northern Diamonds vs Western Storm
2023-09-10 - club - RHF - female - 1347449 - Central Sparks vs Sunrisers
2023-09-10 - club - RHF - female - 1347447 - South East Stars vs The Blaze
2023-09-09 - club - RHF - female - 1347448 - Southern Vipers vs Thunder
2023-09-05 - club - RHF - female - 1347446 - Southern Vipers vs Northern Diamonds
2023-09-05 - club - RHF - female - 1347445 - Western Storm vs Sunrisers
2023-09-05 - club - RHF - female - 1347444 - Central Sparks vs The Blaze
2023-09-05 - club - RHF - female - 1347443 - South East Stars vs Thunder
2023-07-24 - club - RHF - female - 1347442 - Western Storm vs Sunrisers
2023-07-22 - club - RHF - female - 1347441 - Western Storm vs South East Stars
2023-07-22 - club - RHF - female - 1347438 - Northern Diamonds vs Southern Vipers
2023-07-17 - club - RHF - female - 1347437 - The Blaze vs South East Stars
2023-07-15 - club - RHF - female - 1347435 - Western Storm vs Southern Vipers
2023-07-15 - club - RHF - female - 1347434 - Northern Diamonds vs Central Sparks
2023-07-11 - club - RHF - female - 1347433 - Northern Diamonds vs Thunder
2023-07-11 - club - RHF - female - 1347432 - Southern Vipers vs The Blaze
2023-07-11 - club - RHF - female - 1347431 - South East Stars vs Sunrisers
2023-07-07 - club - RHF - female - 1347429 - Southern Vipers vs Thunder
2023-07-07 - club - RHF - female - 1347428 - Central Sparks vs South East Stars
2023-07-07 - club - RHF - female - 1347427 - Northern Diamonds vs The Blaze
2023-07-02 - club - RHF - female - 1347426 - South East Stars vs Northern Diamonds
2023-07-02 - club - RHF - female - 1347425 - Sunrisers vs Southern Vipers
2023-07-02 - club - RHF - female - 1347424 - Central Sparks vs Thunder
2023-07-02 - club - RHF - female - 1347423 - The Blaze vs Western Storm
2023-05-10 - club - RHF - female - 1347422 - The Blaze vs Western Storm
2023-05-10 - club - RHF - female - 1347421 - Southern Vipers vs Central Sparks
2023-05-10 - club - RHF - female - 1347420 - South East Stars vs Northern Diamonds
2023-05-10 - club - RHF - female - 1347419 - Thunder vs Sunrisers
2023-05-06 - club - RHF - female - 1347417 - Northern Diamonds vs The Blaze
2023-05-06 - club - RHF - female - 1347416 - Thunder vs Central Sparks
2023-05-05 - club - RHF - female - 1347415 - South East Stars vs Sunrisers
2023-05-01 - club - RHF - female - 1347414 - South East Stars vs Western Storm
2023-05-01 - club - RHF - female - 1347413 - Sunrisers vs Northern Diamonds
2023-05-01 - club - RHF - female - 1347412 - Central Sparks vs Southern Vipers
2023-04-29 - club - RHF - female - 1347410 - Southern Vipers vs South East Stars
2023-04-29 - club - RHF - female - 1347409 - Sunrisers vs The Blaze
2023-04-29 - club - RHF - female - 1347408 - Thunder vs Western Storm
2023-04-29 - club - RHF - female - 1347407 - Northern Diamonds vs Central Sparks
2023-04-22 - club - RHF - female - 1347406 - The Blaze vs Central Sparks
2023-04-22 - club - RHF - female - 1347405 - Northern Diamonds vs Western Storm
2023-04-22 - club - RHF - female - 1347404 - South East Stars vs Thunder
2023-04-22 - club - RHF - female - 1347403 - Sunrisers vs Southern Vipers
2022-09-25 - club - RHF - female - 1297956 - Northern Diamonds vs Southern Vipers
2022-09-21 - club - RHF - female - 1297955 - South East Stars vs Southern Vipers
2022-09-18 - club - RHF - female - 1297951 - Thunder vs Western Storm
2022-09-17 - club - RHF - female - 1297954 - South East Stars vs Lightning
2022-09-17 - club - RHF - female - 1297953 - Central Sparks vs Sunrisers
2022-09-17 - club - RHF - female - 1297952 - Southern Vipers vs Northern Diamonds
2022-09-11 - club - RHF - female - 1297950 - Northern Diamonds vs Western Storm
2022-09-11 - club - RHF - female - 1297949 - Lightning vs Sunrisers
2022-09-11 - club - RHF - female - 1297948 - South East Stars vs Central Sparks
2022-09-11 - club - RHF - female - 1297947 - Thunder vs Southern Vipers
2022-07-23 - club - RHF - female - 1297942 - Lightning vs Northern Diamonds
2022-07-23 - club - RHF - female - 1297941 - Thunder vs Central Sparks
2022-07-23 - club - RHF - female - 1297940 - South East Stars vs Western Storm
2022-07-23 - club - RHF - female - 1297939 - Southern Vipers vs Sunrisers
2022-07-16 - club - RHF - female - 1297938 - Southern Vipers vs Lightning
2022-07-16 - club - RHF - female - 1297937 - Sunrisers vs Western Storm
2022-07-16 - club - RHF - female - 1297936 - South East Stars vs Thunder
2022-07-16 - club - RHF - female - 1297935 - Central Sparks vs Northern Diamonds
2022-07-09 - club - RHF - female - 1297934 - Southern Vipers vs South East Stars
2022-07-09 - club - RHF - female - 1297933 - Thunder vs Lightning
2022-07-09 - club - RHF - female - 1297932 - Northern Diamonds vs Sunrisers
2022-07-09 - club - RHF - female - 1297931 - Central Sparks vs Western Storm
2022-07-03 - club - RHF - female - 1297930 - Thunder vs Northern Diamonds
2022-07-02 - club - RHF - female - 1297929 - Central Sparks vs Southern Vipers
2022-07-02 - club - RHF - female - 1297928 - Western Storm vs Lightning
2022-07-02 - club - RHF - female - 1297927 - South East Stars vs Sunrisers
2022-06-25 - club - SFT - female - wi_212064 - Barbados vs Jamaica
2022-06-24 - club - SFT - female - wi_212063 - Windward Islands vs Leeward Islands
2022-06-23 - club - SFT - female - wi_212062 - Guyana vs Jamaica
2022-06-22 - club - SFT - female - wi_212061 - Barbados vs Trinidad and Tobago
2022-06-21 - club - SFT - female - wi_211979 - Guyana vs Leeward Islands
2022-06-20 - club - SFT - female - wi_211973 - Jamaica vs Windward Islands
2022-06-18 - club - SFT - female - wi_211977 - Jamaica vs Barbados
2022-06-17 - club - SFT - female - wi_211976 - Trinidad and Tobago vs Leeward Islands
2021-11-27 - international - ODM - female - 1286916 - United States of America vs Thailand
2021-11-25 - international - ODM - female - 1286912 - United States of America vs Zimbabwe
2021-11-25 - international - ODM - female - 1286910 - Bangladesh vs Thailand
2021-11-25 - international - ODM - female - 1286904 - Ireland vs Netherlands
2021-11-23 - international - ODM - female - 1286908 - Bangladesh vs United States of America
2021-11-23 - international - ODM - female - 1286907 - Pakistan vs Thailand
2021-11-23 - international - ODM - female - 1286906 - Sri Lanka vs Netherlands
2021-11-21 - international - ODM - female - 1286902 - Thailand vs Zimbabwe
2021-09-25 - club - RHF - female - 1252293 - Northern Diamonds vs Southern Vipers
2021-09-22 - club - RHF - female - 1252292 - Central Sparks vs Northern Diamonds
2021-09-18 - club - RHF - female - 1252291 - Northern Diamonds vs Southern Vipers
2021-09-18 - club - RHF - female - 1252290 - Western Storm vs Sunrisers
2021-09-18 - club - RHF - female - 1252289 - Thunder vs South East Stars
2021-09-18 - club - RHF - female - 1252288 - Lightning vs Central Sparks
2021-09-12 - club - RHF - female - 1252287 - Southern Vipers vs Sunrisers
2021-09-12 - club - RHF - female - 1252286 - Western Storm vs Lightning
2021-09-12 - club - RHF - female - 1252285 - Central Sparks vs South East Stars
2021-09-12 - club - RHF - female - 1252284 - Northern Diamonds vs Thunder
2021-09-10 - club - RHF - female - 1252283 - Thunder vs Southern Vipers
2021-09-10 - club - RHF - female - 1252282 - Sunrisers vs Central Sparks
2021-09-10 - club - RHF - female - 1252281 - South East Stars vs Lightning
2021-09-10 - club - RHF - female - 1252280 - Western Storm vs Northern Diamonds
2021-06-12 - club - RHF - female - 1252279 - Western Storm vs Southern Vipers
2021-06-12 - club - RHF - female - 1252278 - Central Sparks vs Thunder
2021-06-12 - club - RHF - female - 1252277 - Sunrisers vs Lightning
2021-06-12 - club - RHF - female - 1252276 - South East Stars vs Northern Diamonds
2021-06-06 - club - RHF - female - 1252274 - Lightning vs Thunder
2021-06-05 - club - RHF - female - 1252275 - Central Sparks vs Southern Vipers
2021-06-05 - club - RHF - female - 1252273 - Sunrisers vs Northern Diamonds
2021-06-05 - club - RHF - female - 1252272 - Western Storm vs South East Stars
2021-05-31 - club - RHF - female - 1252271 - Thunder vs Sunrisers
2021-05-31 - club - RHF - female - 1252270 - South East Stars vs Southern Vipers
2021-05-31 - club - RHF - female - 1252269 - Central Sparks vs Western Storm
2021-05-31 - club - RHF - female - 1252268 - Northern Diamonds vs Lightning
2021-05-29 - club - RHF - female - 1252267 - Lightning vs Southern Vipers
2021-05-29 - club - RHF - female - 1252266 - South East Stars vs Sunrisers
2021-05-29 - club - RHF - female - 1252265 - Thunder vs Western Storm
2021-05-29 - club - RHF - female - 1252264 - Northern Diamonds vs Central Sparks
2021-02-09 - international - ODM - female - 1249285 - Pakistan vs Zimbabwe
2020-09-27 - club - RHF - female - 1229350 - Southern Vipers vs Northern Diamonds
2020-09-19 - club - RHF - female - 1229349 - Western Storm vs Sunrisers
2020-09-19 - club - RHF - female - 1229348 - Lightning vs Central Sparks
2020-09-19 - club - RHF - female - 1229347 - Thunder vs Northern Diamonds
2020-09-19 - club - RHF - female - 1229346 - South East Stars vs Southern Vipers
2020-09-13 - club - RHF - female - 1229345 - Northern Diamonds vs Central Sparks
2020-09-13 - club - RHF - female - 1229344 - Thunder vs Lightning
2020-09-13 - club - RHF - female - 1229343 - Sunrisers vs South East Stars
2020-09-13 - club - RHF - female - 1229342 - Southern Vipers vs Western Storm
2020-09-11 - club - RHF - female - 1229341 - Lightning vs Central Sparks
2020-09-11 - club - RHF - female - 1229340 - Southern Vipers vs Sunrisers
2020-09-11 - club - RHF - female - 1229339 - South East Stars vs Western Storm
2020-09-10 - club - RHF - female - 1229338 - Northern Diamonds vs Thunder
2020-09-05 - club - RHF - female - 1229337 - Southern Vipers vs South East Stars
2020-09-05 - club - RHF - female - 1229336 - Lightning vs Northern Diamonds
2020-09-05 - club - RHF - female - 1229335 - Western Storm vs Sunrisers
2020-09-05 - club - RHF - female - 1229334 - Thunder vs Central Sparks
2020-08-31 - club - RHF - female - 1229333 - Northern Diamonds vs Lightning
2020-08-31 - club - RHF - female - 1229332 - Thunder vs Central Sparks
2020-08-31 - club - RHF - female - 1229331 - South East Stars vs Sunrisers
2020-08-31 - club - RHF - female - 1229330 - Southern Vipers vs Western Storm
2020-08-29 - club - RHF - female - 1229329 - South East Stars vs Western Storm
2020-08-29 - club - RHF - female - 1229326 - Sunrisers vs Southern Vipers
2017-05-19 - international - ODM - female - 1089531 - India vs Zimbabwe
2017-05-17 - international - ODM - female - 1089529 - Ireland vs Zimbabwe
2017-05-15 - international - ODM - female - 1089526 - South Africa vs Zimbabwe
2017-05-11 - international - ODM - female - 1089525 - India vs Zimbabwe
2017-05-09 - international - ODM - female - 1089523 - Ireland vs Zimbabwe
2017-05-07 - international - ODM - female - 1089520 - South Africa vs Zimbabwe
2017-02-13 - international - ODM - female - 1073420 - Pakistan vs Scotland
2017-02-13 - international - ODM - female - 1073419 - Papua New Guinea vs South Africa
2017-02-13 - international - ODM - female - 1073418 - Sri Lanka vs Thailand
2017-02-13 - international - ODM - female - 1073417 - India vs Zimbabwe
2017-02-11 - international - ODM - female - 1073416 - Ireland vs Thailand
2017-02-11 - international - ODM - female - 1073415 - Sri Lanka vs Zimbabwe
2017-02-11 - international - ODM - female - 1073414 - Papua New Guinea vs Scotland
2017-02-10 - international - ODM - female - 1073412 - Thailand vs Zimbabwe
2017-02-10 - international - ODM - female - 1073410 - Bangladesh vs Scotland
2017-02-10 - international - ODM - female - 1073409 - Papua New Guinea vs Pakistan
2017-02-08 - international - ODM - female - 1073407 - Scotland vs South Africa
2017-02-08 - international - ODM - female - 1073406 - India vs Thailand
2017-02-07 - international - ODM - female - 1073404 - Bangladesh vs Papua New Guinea
2017-02-07 - international - ODM - female - 1073402 - Ireland vs Zimbabwe
2016-07-15 - international - ODM - female - 1033707 - Netherlands vs Scotland

Further information
-------------------

You can find all of our currently available data at https://cricsheet.org/

You can contact me via the following methods:
  Email   : stephen@cricsheet.org
  Mastodon: @cricsheet@deeden.co.uk
